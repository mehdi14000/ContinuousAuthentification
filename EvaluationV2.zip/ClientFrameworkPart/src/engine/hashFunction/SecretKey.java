package engine.hashFunction;

/**
 * Created by Julien Hatin on 09/12/15.
 */
public interface SecretKey {


}
