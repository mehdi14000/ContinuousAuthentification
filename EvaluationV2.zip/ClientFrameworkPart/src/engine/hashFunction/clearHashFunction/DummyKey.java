package engine.hashFunction.clearHashFunction;

import engine.hashFunction.SecretKey;

/**
 * Created by Julien Hatin on 09/12/15.
 */
@Deprecated
public class DummyKey implements SecretKey {
}
